<div class="footer">
	<div class="container">
		<div class="wrapper-list-footer">
			<div class="row">
				<div class="col-md-6">
					<div class="footer-socmed">
						<h1>
							Nomor Telepon
						</h1>
						<ul>
							<li>
								<?php echo $about->phone ?>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-md-6">
					<div class="footer-address">
						<h1>
							Alamat
						</h1>
						<span>
							<?php echo $about->address ?>
						</span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer-copyright">
		<div class="container">
			<div class="copyright">
				&copy; CEPI STORE 2023
			</div>
			<div class="about-me">
				CEPI STORE
			</div>
		</div>
	</div>
</div>
