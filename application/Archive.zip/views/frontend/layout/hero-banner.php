<div class="hero-banner">
	<div class="row">
		<div class="col-md-8">
			<div class="tagline-hero">
				<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
					<div class="carousel-inner">
						<div class="carousel-item active">
							<span>
								Selamat datang di
							</span>
							<h1>Cepi Store, Gudangnya Fashion.</h1>
						</div>
						<div class="carousel-item">
							<span>
								Belanja Puas
							</span>
							<h1>Harga Pas.</h1>
						</div>
						<div class="carousel-item">
							<span>
								Dapatkan Diskon
							</span>
							<h1>Hingga 50% !.</h1>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="image-hero">
				<img src="<?php echo base_url() ?>assets/images/product/img-hero-section.png" alt="hero">
			</div>
		</div>
	</div>
</div>
